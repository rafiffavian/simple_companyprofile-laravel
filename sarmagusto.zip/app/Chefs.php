<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Chefs extends Model
{
    protected $table = "chef";
    protected $guarded = [];
}
