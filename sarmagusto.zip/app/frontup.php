<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class frontup extends Model
{
    protected $table = "frontup";
    protected $guarded = [];
}
